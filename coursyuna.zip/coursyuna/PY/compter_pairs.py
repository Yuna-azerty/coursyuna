'''
compter le nombre d'éléments pairs dans une liste
len(L) -> nombres d'éléments de la liste entre parenthèses
for i range(len(L)) : i va de 0 à len(L) - 1
L[i] : l'élément d'indice i
'''
L= [2, 7, 1.6, 8, 11, 12, 4, 33]
cpt= 0
for i in range(len(L)):
    if L[i]%2==0:
        cpt += 1
print(cpt) 

for val in L:
    if val%2 == 0:
        cpt+=1
print(cpt)