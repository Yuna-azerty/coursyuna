age_minimum=12
age_rentre=int(input("Donner votre age : "))
if age_rentre<age_minimum:
    print("Vous ne pouvez pas y aller")
elif age_rentre==age_minimum:
    print("Vous avez pile l'age pour y aller")
else:
    print("Allez-y !")
