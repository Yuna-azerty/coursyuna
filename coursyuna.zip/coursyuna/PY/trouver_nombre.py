#Trouver 7 : la question est reposée jusqu'à que le nombre soit trouvé
nombreATrouver=7
nombreRentre=int(input("Donner un nombre : "))
while nombreRentre!=nombreATrouver:
    nombreRentre = int(input("Donner un nombre : "))

    

    

    
    
