#Pour aller de 0 à 15
for i in range(16):
    print("Le chiffre est : ", i ) 

#Pour aller de 1 à 15
for i in range(1,16):
    print("Le chiffre est : ", i ) 
    
#Pour aller de 15 à 0
for i in range(16):
    print("Le chiffre est : ", i ) 
    
#Pour aller de 15 à 1
for i in range(15,0,-1):
    print("Le chiffre est : ", i ) 
    nombreMax = int(input("Donner un nombre :"))

#Donner un nombre et aller jusqu'à ce nombre        
nombreMax =  int(input("Donner un nombre : "))
for a in range(1, nombreMax+1):
    print(a)
    