'''
len(L) -> nombres d'éléments de la liste entre parenthèses
for i range(len(L)) : i va de 0 à len(L) - 1
L[i] : l'élément d'indice i
chaine = "salut" équivalent à chaine = ['s', 'a', 'l', 'u', 't']
'''
phrase = "Bonjour j'apprends le langage python"
cpt = 0
for val in phrase:
    if val == 'e':
        cpt+=1
print(cpt)