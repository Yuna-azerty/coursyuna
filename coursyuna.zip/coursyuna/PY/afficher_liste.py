'''
afficher les éléments dans une liste
len(L) -> nombres d'éléments de la liste entre parenthèses
for i range(len(L)) : i va de 0 à len(L) - 1
L[i] : l'élément d'indice i
'''

L= [2, 7, 1.6, 8, 11, 12, 4, 33]

for i in range (len(L)):
    print(L[i])
    
