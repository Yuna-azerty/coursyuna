#Ajouter un compteur égal à 5, si le nombre n'est pas trouvé au bout de 5 fois, arrêter le jeu 
import random
compteur=5
nombre=random.randint(1,20)
nombre_rentre=int(input("Donner un nombre : "))
while nombre_rentre!=nombre:
    compteur-=1
    if compteur==0:
        print ("Perdu: le nombre est",nombre)
        break 
    if nombre_rentre < nombre:
        print("Plus grand")
    elif nombre_rentre > nombre:
        print("Plus petit")
    nombre_rentre=int(input("Donner un nombre : "))    
if nombre_rentre==nombre:
        print("Trouvé:", nombre)