#Créer un programme qui vérifie si un nombre donné par
# l'utilisateur est pair ou impair et affiche le résultat.

nd= int(input("Donner un nombre : "))
if nd%2==0:
    print ("Le nombre est pair")
else:
    print ("le nombre est impair")

