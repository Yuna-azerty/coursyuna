'''
Demander une lettre (avec input()) et compter le nombre de 
lettre donné dans une phrase (elle aussi donnée avec input())
Soit une liste 'maListe'
maListe -> une liste qui contient des éléments
'''

'''
Explication de la ligne suivante : for i in range(len(maListe))

len(maListe) -> nombre d'éléments de 'maListe'
i -> un entier qui va de 0 à len(maListe)
maListe[i] -> l'élément de 'maListe' d'indice 'i'
'''

lettre = input("Donner une lettre: ")
phrase = input("Donner une phrase: ")
posLettre = []
cpt = 0

for i in range(len(phrase)) :