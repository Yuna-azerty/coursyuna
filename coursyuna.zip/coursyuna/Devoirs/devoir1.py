#Jeux : Trouver le nombre entre 1 et 20 
    #Affecter un nombre entre 1 et 20 à une variable
    #demander un nombre : si plus petit que celui à trouver, 
    # écrire "plus petit" sinon écrire "plus grand" et si le nombre est égal écrire "trouvé !"
import random
nombre_a_trouver=random.randint(1, 20) 
nombre_rentre=int(input("Donner un nombre : ")) 
while nombre_a_trouver != nombre_rentre :
    if nombre_rentre < nombre_a_trouver:
        print("Plus grand")
    elif nombre_rentre > nombre_a_trouver:
        print("Plus petit")
    else: 
        print("Trouvé")
    nombre_rentre=int(input("Donner un nombre : ")) 