# Initialisation de notre tortue dans la variable t

t = turtle.Turtle()
import turtle

# L t
t.right(90)
t.forward(110)
t.left(90)
t.forward(60)

t.setheading(90)
t.forward(110)
t.setheading(90)
t.forward(60)

# H t
t.right(90)                 
t.forward(100)
t.left(180)
t.forward(50)
t.right(90)
t.forward(50)
t.left(90)
t.forward(50)
t.left(180)
t.forward(100)

# setheading met vers une direction 
# right left tourne d'un certain nombre de degrés 
t.setheading(90)
t.forward(100)
t.setheading(270)
t.forward(50)
t.setheading(90)
t.forward(50)
t.setheading(270)
t.forward(50)
t.setheading(270)
t.forward(100)

turtle.done()

