import turtle
import random   # permet d'importer la bibliothèque hasard ligne 23

# Définir condition d'arrêt devoir
# Configuration de l'écran (petite fenêtre)
screen = turtle.Screen()
screen.title("Snake Simplifié")
screen.bgcolor("black")
screen.setup(width=600, height=600)
screen.tracer(0)

# Création du serpent
snake = turtle.Turtle()
snake.shape("square")
snake.color("white")
snake.penup()           # dessiner
snake.speed(0)          # immobile au début

# Création de la nourriture
food = turtle.Turtle()
food.shape("circle")
food.color("red")
food.penup()
food.goto(random.randint(-280, 280), random.randint(-280, 280))     # random.randit --> se rendre à une coordonnée au hasard entre -280 et 280
                                                                    # goto          --> se rendre à une coordonnée précise et définie
                                                                    #                   (x abscisse, y ordonnée)
# Variables du mouvement
direction = "stop"
segments = []

# Fonctions de mouvement on ne peut pas se retourner de 360°
def go_up():
    global direction
    if direction != "down":
        direction = "up"

def go_down():
    global direction
    if direction != "up":
        direction = "down"

def go_left():
    global direction
    if direction != "right":
        direction = "left"

def go_right():
    global direction
    if direction != "left":
        direction = "right"

cpt=0


# Liaison des touches clavier
screen.listen()
screen.onkey(go_up, "Up")
screen.onkey(go_down, "Down")
screen.onkey(go_left, "Left")
screen.onkey(go_right, "Right")

# Boucle de jeu et compteur pas
def game_loop():
    global direction
    global cpt

    # Déplacement du serpent
    if direction == "up":           # renvoie à ligne 31
        y = snake.ycor()            # ordonnée
        snake.sety(y + 20)          # avancer
    if direction == "down":
        y = snake.ycor()
        snake.sety(y - 20)
    if direction == "left":
        x = snake.xcor()
        snake.setx(x - 20)
    if direction == "right":
        x = snake.xcor()
        snake.setx(x + 20)
    cpt+=1 

    # Vérification si le serpent mange la nourriture et compteur de nourriture
    food == 0
    if snake.distance(food) < 20:
        food.goto(random.randint(-280, 280), random.randint(-280, 280))
        food += 1
        
    # Ajout d'un segment au serpent
        segment = turtle.Turtle()
        segment.shape("square")
        segment.color("grey")
        segment.penup()
        segments.append(segment)

    # Déplacement du corps du serpent
    for i in range(len(segments) - 1, 0, -1):
        x = segments[i - 1].xcor()
        y = segments[i - 1].ycor()
        segments[i].goto(x, y)

    if segments:
        segments[0].goto(snake.xcor(), snake.ycor())

    # Paramètres fin  
    if food == 10 :
        print("J'ai fait", cpt)
    screen.update()
    screen.ontimer(game_loop, 100)  # Appelle la boucle toutes les 100ms

# Démarrer le jeu
game_loop()
screen.mainloop()