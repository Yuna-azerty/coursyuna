#Créer les fonctions de déplacements bas, droite et gauche
#Écrire les écoutes pour ces mêmes mouvements

# Initialisation de notre tortue dans la variable t
import turtle
t = turtle.Turtle()
screen = turtle.Screen()
screen.title("Déplacement avec les flèches")

# Compteur 

# Nbr de pas max
pas_max=int(input("Donner un nombre de pas maximum "))
print(pas_max)

# Création du point rouge
point = turtle.Turtle()
point.penup()
point.shape("circle")
point.color("red")
point.goto(250, -150)  # Position du point rouge

pas=0 

# Fonction pour vérifier si la tortue est arrivée au point rouge
def verifier_arrivee():
    global pas
    global pas_max
    pas +=1
    if t.distance(point) < 15:  # Distance de collision
        print("Tu es arrivé !")
        if pas < pas_max:
            print ("Tu as atteint ton objectif")
        elif pas > pas_max:
            print ("Tu as échoué !")
        point.hideturtle()  # Cache le point rouge une fois atteint
        print("Tu as fait",pas, "pas")
        
# Fonctions pour déplacer la tortue
        # Oriente vers le haut
def haut():
    t.setheading(90)  
    t.forward(20)
    verifier_arrivee()

        # Oriente vers le bas
def bas() :
    t.setheading(270) 
    t.forward(20)
    verifier_arrivee()

        # Oriente vers la droite
def droite() :
    t.setheading(0)
    t.forward(20)
    verifier_arrivee()

        # Oriente vers la gauche
def gauche() :
    t.setheading(180)
    t.forward(20)
    verifier_arrivee()

# Liaison des touches du clavier aux fonctions
screen.listen()
screen.onkey(haut, "Up")      # Flèche haut
screen.onkey(bas,  "Down")     # Flèche bas
screen.onkey(gauche,"Left")  # Flèche gauche
screen.onkey(droite,"Right") # Flèche droite

# Boucle principale
screen.mainloop()
