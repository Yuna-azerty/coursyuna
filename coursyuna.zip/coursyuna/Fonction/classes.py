class Voiture:
    # Constructeur des attributs
    def __init__(self, color, seats):
        self.color = color # Attribut couleur de la voiture
        self.seats = seats # Attribut des places de la voiture
        self.type = "Essence" # Attribut du type de la voiture
        self.state = False 
        # autres attributs ?

    def start(self):
        if self.state == False :  # = if not self.state             
            print("Le véhicule a démarré") 
            self.state = True 
        else :
            print("Le véhicule a déjà démarré")

    def stop(self):
        if self.state == True :  # = if self.state
            print("Le moteur est coupé") 
            self.state = False 
        else :
            print("Le moteur ne peut pas être coupé")
        

    def print_color(self):
        print(self.color)

    def print_seats(self):
        print(self.seats)

    def print_type(self):
        print(self.type)

blue_car = Voiture("bleu", 4)
blue_car.print_color()
blue_car.start()
