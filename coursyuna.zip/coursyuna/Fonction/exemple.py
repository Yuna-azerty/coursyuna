def verif_argent(argent):                                                                        
    '''                                 
    Vérifie si la variable argent est bien supérieur strictement à 15
    '''
    if argent > 15:
        return True
    else:
        return False

argent_personne1 = 8 #euros
argent_personne2 = 20 #euros
argent_personne3 = 16 #euros

print(verif_argent(argent_personne1))
print(verif_argent(argent_personne2))
print(verif_argent(argent_personne3))                                                                                                                                                              