def somme(liste)  :     # on donne une liste à traiter
    s=0
    for i in range(len(liste)):
        s += liste[i]
    return s 
print(somme([1, 4, 2])) # 7